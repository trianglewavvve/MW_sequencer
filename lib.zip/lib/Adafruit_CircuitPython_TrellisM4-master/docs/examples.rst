Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/trellism4_simpletest.py
    :caption: examples/trellism4_simpletest.py
    :linenos:
